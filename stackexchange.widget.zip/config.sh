#!/bin/sh

# auth
# 1. goto https://stackexchange.com/oauth/dialog?client_id=5175&scope=no_expiry,read_inbox&redirect_uri=http://stackexchange.com
# 2. copy token attached to url

# Configuration
site="stackoverflow"
token="yHp4GrEgFAhoaza9gtyb*A))"